To run our code, run the following command:
```
python3 proj2.py
```

Our report is available in `project2_report.pdf`. The values of phi for individual 1 is stored in `phi1.out` and the 
values of theta for all populations are stored in `Theta.out`

Additional visualization code is stored in `Visualization.ipynb`. Our experiments that vary alpha has their results 
stored in `varying_alpha.csv`.
