To run our code, run the following command:
```
python3 project1.py
```

Our report is available in `project1_report.pdf`. The results are stored in `/result/`.
```
assignment/  # shows the assignment of pixels to vanishing points
final-assign-vp/  # shows the assignment of pixels and the final location of vanishing points
final-vp/  # shows the final location of vanishing points after using EM
initial-vp/  # shows the initial location of vanishing points using the initial Bayesian estimates
```
