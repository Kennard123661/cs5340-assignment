# CS5340 Project AY2019/2020 Sem 1

Access each project folder and read the `readme.md` files. They will provide information on our code, results and report. 
