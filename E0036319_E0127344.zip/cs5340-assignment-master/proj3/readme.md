To run our code, run the following command:
```
python3 proj3_helper_functions.py
```

Our report is available in `project3_report.pdf`. The output context-aware resized image is stored in `./image_output.jpg`.

